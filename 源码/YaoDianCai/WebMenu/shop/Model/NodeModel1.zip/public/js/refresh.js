window.location = "/index";
