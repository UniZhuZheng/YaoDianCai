var SID='0512000032';var name='东东';
var host='http://192.168.0.105:8082';
var localIp = 'http://localhost:8089';