var SID='0512000047';var name='名典咖啡语茶（凤凰店）';var host='http://192.168.0.105:8082';var localIp='http://192.168.0.181:8889';
