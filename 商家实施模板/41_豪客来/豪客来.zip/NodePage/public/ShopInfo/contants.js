var SID='0512000043';var name='豪客来';var host='http://192.168.0.105:8082';var localIp='http://192.168.0.181:0044';
