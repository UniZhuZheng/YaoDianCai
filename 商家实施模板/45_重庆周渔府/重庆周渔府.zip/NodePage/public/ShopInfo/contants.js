var SID='0512000046';var name='重庆周渔府';var host='http://192.168.0.105:8082';var localIp='http://192.168.0.181:8023';
;
