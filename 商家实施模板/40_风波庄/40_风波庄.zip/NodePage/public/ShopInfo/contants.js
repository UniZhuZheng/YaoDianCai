var SID='0512000042';var name='风波庄';var host='http://192.168.0.105:8082';var localIp='http://192.168.0.181:8899';
