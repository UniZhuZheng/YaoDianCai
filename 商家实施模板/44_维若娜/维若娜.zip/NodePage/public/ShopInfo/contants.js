var SID='0512000045';var name='维若娜';var host='http://192.168.0.105:8082';var localIp='http://192.168.0.181:8074';
